<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = mysqli_connect('localhost','u353026399_root','Systemsdesign5910@','u353026399_systemdesign');

?>